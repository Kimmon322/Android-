package gen;

import android.view.View;

public final class R {
	public String icon = "";
	public static final class layout {
		public static final int main = 0;
		public static final int main2 = 1;
		public static final int mycontacts = 1;
		public static View media_preview;
	}
	public static final class id {
		public static final int topscore = 0;
		public static final int toptime = 1;
		public static final int lay = 0;
		public static final int mySpinner = 0;
		public static final int myImage = 0;
	}
	public static final class drawable {
		public static final int img = 0;
	}
}
