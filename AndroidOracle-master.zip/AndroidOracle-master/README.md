"# AndroidOracle" 
